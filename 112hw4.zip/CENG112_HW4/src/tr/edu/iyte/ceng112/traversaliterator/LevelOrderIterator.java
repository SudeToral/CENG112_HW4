package tr.edu.iyte.ceng112.traversaliterator;

import java.util.Iterator;

import tr.edu.iyte.ceng112.tree.BinaryNode;
import tr.edu.iyte.ceng112.queue.QueueInterface;
import tr.edu.iyte.ceng112.queue.ArrayQueue;
import tr.edu.iyte.ceng112.queue.EmptyQueueException;

public class LevelOrderIterator<T> implements Iterator<T> {
    private QueueInterface<BinaryNode<T>> queue;


    public LevelOrderIterator(BinaryNode<T> root,int size) {
        queue = new ArrayQueue<>(size);
        if (root != null) {
            queue.enqueue(root);
        }
    }

    @Override
    public boolean hasNext() {
        return !queue.isEmpty();
    }

    @Override
    public T next() {
        if (!hasNext()) {
             new EmptyQueueException();
        }

        BinaryNode<T> current;
		try {
			current = queue.dequeue();

	        if (current.getLeftChild() != null) {
	            queue.enqueue(current.getLeftChild());
	        }

	        if (current.getRightChild() != null) {
	            queue.enqueue(current.getRightChild());
	        }

	        return current.getData();
		} catch (EmptyQueueException e) {
			
			e.printStackTrace();
			return null;
		}


    }

}

