package tr.edu.iyte.ceng112.traversaliterator;

import java.util.Iterator;

import tr.edu.iyte.ceng112.stack.ArrayStack;
import tr.edu.iyte.ceng112.stack.StackInterface;
import tr.edu.iyte.ceng112.tree.BinaryNode;

 public class PreorderIterator<T> implements Iterator<T>  {
	 	private StackInterface<BinaryNode<T>> stack;
	

	    public PreorderIterator(BinaryNode<T> root) {
	    	stack = new ArrayStack<>();
	    	if (root != null)
	                init(root);}

        
		private void init(BinaryNode<T> root) {
            stack.push(root);
        }



		public T next() {
            BinaryNode<T> currentnode = stack.pop();
            if (currentnode.getRightChild() != null)
                init(currentnode.getRightChild());
            if (currentnode.getLeftChild() != null)
                init(currentnode.getLeftChild());
            return (T) currentnode.getData();
        }


        public boolean hasNext() {
        	return !stack.isEmpty();
        }
    }






