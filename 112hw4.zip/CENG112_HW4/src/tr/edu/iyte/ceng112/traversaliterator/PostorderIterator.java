package tr.edu.iyte.ceng112.traversaliterator;

import java.util.Iterator;

import tr.edu.iyte.ceng112.stack.ArrayStack;
import tr.edu.iyte.ceng112.stack.StackInterface;
import tr.edu.iyte.ceng112.tree.BinaryNode;

public class PostorderIterator<T> implements Iterator<T> {

    private StackInterface<BinaryNode<T>> stack;

    public PostorderIterator(BinaryNode<T> root) {
    	stack = new ArrayStack<BinaryNode<T>>();
        init(root);

    }
    private void init(BinaryNode<T> root) {
        while (root != null) {
        	stack.push(root);
        	if (root.getLeftChild() != null)
                root = root.getLeftChild();
            else
                root = root.getRightChild();
        }
    }


    public T next() {
    	BinaryNode<T> node = stack.pop();
    	if (!stack.isEmpty()) {
            if (node == stack.peek().getLeftChild()) {
                init(stack.peek().getRightChild()); 
            }

            
        }
        return node.getData();
    }


    public boolean hasNext() {

        return !stack.isEmpty();
    }
}


