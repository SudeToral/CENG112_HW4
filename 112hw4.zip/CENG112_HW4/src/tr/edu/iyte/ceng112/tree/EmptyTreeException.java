package tr.edu.iyte.ceng112.tree;

public class EmptyTreeException extends Exception {

	private static final long serialVersionUID = 1L;

}
