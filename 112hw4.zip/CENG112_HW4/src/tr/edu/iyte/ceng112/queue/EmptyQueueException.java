package tr.edu.iyte.ceng112.queue;

public class EmptyQueueException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public EmptyQueueException() {
		// TODO Auto-generated constructor stub
	}

}
